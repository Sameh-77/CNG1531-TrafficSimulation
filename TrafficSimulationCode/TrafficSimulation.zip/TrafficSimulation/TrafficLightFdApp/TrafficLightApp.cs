// **************************************************************************************************
//		CTrafficLightApp
//
//		generated
//			by		: 	Simulation Generator (SimGe) v.0.3.3
//			at		: 	Sunday, January 30, 2022 4:43:41 PM
//		compatible with		: 	RACoN v.0.0.2.5
//
//		copyright		: 	(C) 
//		email			: 	
// **************************************************************************************************
/// <summary>
/// The application specific federate that is extended from the Generic Federate Class of RACoN API. This file is intended for manual code operations.
/// </summary>

// System
using System;
using System.Collections.Generic; // for List
// Racon
using Racon;
using Racon.RtiLayer;
// Application
using TrafficSimulation.Som;

namespace TrafficSimulation
{
  public partial class CTrafficLightApp : Racon.CGenericFederate
  {
    
    
   
    
        #region Manually Added Code
        private object thisLock = new object();

        // DDM Declarations
        public HlaRegion aor1;
        public HlaRegion aor2;
        public HlaRegion aor3;
        public HlaRegion aor4;
        // FdAmb_InteractionReceivedHandler
        public override void FdAmb_InteractionReceivedHandler(object sender, HlaInteractionEventArgs data)
        {
            // Call the base class handler
            base.FdAmb_InteractionReceivedHandler(sender, data);

            if (data.Interaction.ClassHandle == Som.trafficLightMessageIC.Handle)
            {
                Console.WriteLine("Recieved: " + Som.trafficLightMessageIC.Handle);

                if (data.IsValueUpdated(Som.trafficLightMessageIC.color))
                {
                    string color = data.GetParameterValue<string>(Som.trafficLightMessageIC.color);
                    Console.WriteLine("Sign recieved : " + color);
                }

                if (data.IsValueUpdated(Som.trafficLightMessageIC.duration))
                {
                    int duration = data.GetParameterValue<int>(Som.trafficLightMessageIC.duration);
                    Console.WriteLine("Duration recieved : " + duration);
                }

                if (data.IsValueUpdated(Som.trafficLightMessageIC.dataAndtime))
                {
                    string DateTime = data.GetParameterValue<string>(Som.trafficLightMessageIC.dataAndtime);
                    Console.WriteLine("DateTime recieved : " + DateTime);
                }


            }

        }

        // Start Registration
        public override void FdAmb_StartRegistrationForObjectClassAdvisedHandler(object sender, HlaDeclarationManagementEventArgs data)
        {
            // Call the base class handler
            base.FdAmb_StartRegistrationForObjectClassAdvisedHandler(sender, data);
            #region User Code
            // Check that this is for the StationOC
            Console.WriteLine("Registering TrafficLightOC Objects Now");
            if (data.ObjectClassHandle == Som.TrafficLightOC.Handle)
            {
                RegisterHlaObject(Program.TrafficLights[0]);
            }


            if (data.ObjectClassHandle == Som.VehicleOC.Handle)
            {
                RegisterHlaObject(Program.VehicleObject[0]);
            }
            #endregion //User 
        }


        public override void FdAmb_ObjectDiscoveredHandler(object sender, HlaObjectEventArgs data)
        {
            // Call the base class handler
            base.FdAmb_ObjectDiscoveredHandler(sender, data);

            #region User Code
            Console.WriteLine("Discoverting Objects Now!");
            // Check the class type of the discovered object
            if (data.ClassHandle == Som.TrafficLightOC.Handle) // A ship
            {
                // Create and add a new ship to the list
                CTrafficLightHlaObject newTrafficLight = new CTrafficLightHlaObject(data.ObjectInstance);
                newTrafficLight.Type = Som.TrafficLightOC;
                Program.TrafficLights.Add(newTrafficLight);
                Console.WriteLine("\nNew Traffic Light has joined");
                Console.WriteLine("\nTraffiLights are : " + Program.TrafficLights.Count);
                RequestAttributeValueUpdate(newTrafficLight, null);
            }
            else if (data.ClassHandle == Som.VehicleOC.Handle) // A station
            {
                // Create and add a new ship to the list
                CVehicleHlaObject newVehicle = new CVehicleHlaObject(data.ObjectInstance);
                newVehicle.Type = Som.VehicleOC;
                Program.VehicleObject.Add(newVehicle);
                Console.WriteLine("\nNew Vehicle Arrived at Intersection");
                RequestAttributeValueUpdate(newVehicle, null);
            }
            #endregion //User Code
        }

        public override void FdAmb_AttributeValueUpdateRequestedHandler(object sender, HlaObjectEventArgs data)
        {
            // Call the base class handler
            base.FdAmb_AttributeValueUpdateRequestedHandler(sender, data);

            #region User Code
            Console.WriteLine("\nUpdating attribute Values Objects Now");
            // !!! If this federate is created only one object instance, then it is sufficient to check the handle of that object, otherwise we need to check all the collection
            if (data.ObjectInstance.Handle == Program.TrafficLights[0].Handle)
            {
                // We can update all attributes if we dont want to check every attribute.
                var timestamp = Time + Lookahead;
                UpdateTrafficAttribute(Program.TrafficLights[0], timestamp);
            }
            
            #endregion //User Code
        }

        // Reflect Object Attributes
        public override void FdAmb_ObjectAttributesReflectedHandler(object sender, HlaObjectEventArgs data)
        {
            // Call the base class handler
            base.FdAmb_ObjectAttributesReflectedHandler(sender, data);

            Console.WriteLine("\n******************************************\nWaiting to reflect attribute Values for Objects\n");
            foreach (var item in Program.TrafficLights)
            {
                // Update track
                if (data.ObjectInstance.Handle == item.Handle)
                {
                    // Get parameter values - 2nd method
                    foreach (var pair in data.ObjectInstance.Attributes)
                    {
                        if (pair.Handle == Som.TrafficLightOC.status.Handle)
                        {
                            item.TrafficLight.status = pair.GetValue<string>();
                            Console.WriteLine(item.Name + " has sign of " + item.TrafficLight.status);
                        }
                        else if (pair.Handle == Som.TrafficLightOC.timer.Handle)
                        {
                            item.TrafficLight.timer = pair.GetValue<int>();
                        }
                        else if (pair.Handle == Som.TrafficLightOC.position.Handle)
                        {
                            string valueOfPos = pair.GetValue<string>();
                            Console.WriteLine(item.Name + " has position of " + valueOfPos);
                            item.TrafficLight.position = valueOfPos;
                            if (Program.name.ToLower() == "west" && valueOfPos == "east")
                            {
                                Console.WriteLine("We are talking about " + valueOfPos);
                                Program.east++;
                            }
                            else if (Program.name.ToLower() == "east" && valueOfPos == "west")
                            {
                                Program.west++;
                                changeEastToRed();
                            }
                            else if (Program.name.ToLower() == "north" && valueOfPos == "west")
                            {
                                Program.north++;
                            }
                            else if (Program.name.ToLower() == "west" && valueOfPos == "north")
                            {
                                Program.north++;
                                changeWestToRed();
                            }
                            else if (Program.name.ToLower() == "north" && valueOfPos == "south")
                            {
                                Console.WriteLine("We are south");
                                Program.south++;
                                changeNorthToRed();
                            }
                        }
                    }
                }
            }


            foreach (var item in Program.VehicleObject)
            {
                // Update track
                if (data.ObjectInstance.Handle == item.Handle)
                {
                    foreach (var pair in data.ObjectInstance.Attributes)
                    {
                        if (pair.Handle == Som.VehicleOC.id.Handle)
                        {
                            Console.WriteLine(pair.GetValue<string>() + " is arrived at Intersection");
                        }
                        else if (pair.Handle == Som.VehicleOC.position.Handle)
                        {
                             if (Program.TrafficLights[0].TrafficLight.position == pair.GetValue<string>() && Program.TrafficLights[0].TrafficLight.status == "Green")
                            {
                                var tm = Time + Lookahead;
                                SendMessage("Green", 30, tm);
                                Console.WriteLine("GO! Green Light");
                            }
                            else if (Program.TrafficLights[0].TrafficLight.position == pair.GetValue<string>() && Program.TrafficLights[0].TrafficLight.status == "Red")
                            {
                                var tm = Time + Lookahead;
                                SendMessage("Red", 1, tm);
                                Console.WriteLine("WAIT! Red Light");
                            }
                        }
                    }
                }
            }
        }

        public bool SendMessage(string sign, int duration, double timestamp)
        {
            HlaInteraction interaction = new Racon.RtiLayer.HlaInteraction(Som.trafficLightMessageIC, "TrafficLightMessage");

            // Add Values
            interaction.AddParameterValue(Som.trafficLightMessageIC.color, sign);
            interaction.AddParameterValue(Som.trafficLightMessageIC.duration, duration);
            return SendInteraction(interaction, "");
        }


        // Update attribute values
        private bool UpdateTrafficAttribute(CTrafficLightHlaObject light, double timestamp)
        {
            // Add Values
            
            light.AddAttributeValue(Som.TrafficLightOC.status, light.TrafficLight.status);
            light.AddAttributeValue(Som.TrafficLightOC.timer, light.TrafficLight.timer);
            light.AddAttributeValue(Som.TrafficLightOC.position, light.TrafficLight.position);
            var tm = Time + Lookahead;
            foreach (var item in Program.VehicleObject)
            {
                if (item.position.ToLower() == Program.name.ToLower())
                {
                    SendMessage(light.TrafficLight.status, light.TrafficLight.timer, tm);
                }

            }

            return (UpdateAttributeValues(light, "update/reflect"));
        }

        public bool updateSign(CTrafficLightHlaObject light, string sign)
        {
            light.AddAttributeValue(Som.TrafficLightOC.status, sign);
            return (UpdateAttributeValues(light, "update/reflect"));
        }

        // FdAmb_OnSynchronizationPointRegistrationConfirmedHandler
        public override void FdAmb_OnSynchronizationPointRegistrationConfirmedHandler(object sender, HlaFederationManagementEventArgs data)
        {
            // Call the base class handler
            base.FdAmb_OnSynchronizationPointRegistrationConfirmedHandler(sender, data);
            
            #region User Code
            Console.WriteLine("Sync Point request ({0}) is accepted by RTI.",data.Label);
            #endregion //User Code
        }
        // FdAmb_OnSynchronizationPointRegistrationFailedHandler

        public override void FdAmb_OnSynchronizationPointRegistrationFailedHandler(object sender, HlaFederationManagementEventArgs data)
        {
            // Call the base class handler
            base.FdAmb_OnSynchronizationPointRegistrationFailedHandler(sender, data);

            #region User Code
            Console.WriteLine("Pacing request ({0}) is NOT accepted by RTI. Reason: {0}" + Environment.NewLine, data.Label, data.Reason);
            #endregion //User Code
        }
        // FdAmb_SynchronizationPointAnnounced
        public override void FdAmb_SynchronizationPointAnnounced(object sender, HlaFederationManagementEventArgs data)
        {
            // Call the base class handler
            base.FdAmb_SynchronizationPointAnnounced(sender, data);

            #region User Code
            
            Console.WriteLine("Setting All traffic lights signs to red");
            Program.TrafficLights[0].TrafficLight.status = "Red";
            SynchronizationPointAchieved(data.Label, true);
            #endregion //User Code
        }
        // FdAmb_FederationSynchronized
        public override void FdAmb_FederationSynchronized(object sender, HlaFederationManagementEventArgs data)
        {
            // Call the base class handler
            base.FdAmb_FederationSynchronized(sender, data);

            #region User Code
            Console.WriteLine("All lights are red. We can start now.");
            Console.WriteLine("Name of This trafic light : " + Program.name);
            if (Program.name.ToLower() == "east")
            {
                updateEastToGreen();
            }
            #endregion //User Code
        }


        public override void FdAmb_ObjectRemovedHandler(object sender, HlaObjectEventArgs data)
        {
            // Call the base class handler
            base.FdAmb_ObjectRemovedHandler(sender, data);

            #region User Code
            /* object[] snap;
             lock (thisLock)
             {
                 //snap = Program.TrafficLights.ToArray();
             }

             foreach (CTrafficLightHlaObject ship in Program.TrafficLights)
             {
                 if (data.ObjectInstance.Handle == ship.Handle)// Find the Object
                 {
                     Program.TrafficLights.Remove(ship);
                     Console.WriteLine("Number of traffic ligths Now: " + Program.TrafficLights.Count);
                 }
             }*/


            int vlremover;

            for (int i = Program.VehicleObject.Count - 1; i >= 0; i--)
            {
                vlremover = Program.VehicleObject.IndexOf(Program.VehicleObject[i]);
                Program.VehicleObject.RemoveAt(vlremover);
            }
            #endregion //User Code
        }

        public bool updateEastToGreen()
        {
            // Add Values
            CTrafficLightHlaObject light = Program.TrafficLights[0];
            light.TrafficLight.status = "Yellow";
            light.TrafficLight.timer = 5;
            var tm = Time + Lookahead;
            
            light.AddAttributeValue(Som.TrafficLightOC.status, light.TrafficLight.status);
            light.AddAttributeValue(Som.TrafficLightOC.timer, light.TrafficLight.timer);
            light.AddAttributeValue(Som.TrafficLightOC.position, light.TrafficLight.position);
            return (UpdateAttributeValues(light, "update/reflect"));
        }

        public bool turnEastToGreen(CTrafficLightHlaObject light)
        {
            if (light.TrafficLight.status != "Green")
            {
                light.TrafficLight.status = "Green";
                Console.WriteLine("Changing to Green!");
                light.TrafficLight.timer = 30;
                var tm = Time + Lookahead;
                SendMessage("Green", 30, tm);
                Console.WriteLine("GO! Green Light");
                light.AddAttributeValue(Som.TrafficLightOC.status, light.TrafficLight.status);
                light.AddAttributeValue(Som.TrafficLightOC.timer, light.TrafficLight.timer);
                light.AddAttributeValue(Som.TrafficLightOC.position, light.TrafficLight.position);
                return (UpdateAttributeValues(light, "update/reflect"));
            }
            return false;
        }
        public bool turnWestToYellow(CTrafficLightHlaObject light)
        {
            /* if (light.TrafficLight.status != "Green")
             {*/
            light.TrafficLight.status = "Yellow";
            light.TrafficLight.timer = 5;
            light.AddAttributeValue(Som.TrafficLightOC.status, light.TrafficLight.status);
            light.AddAttributeValue(Som.TrafficLightOC.timer, light.TrafficLight.timer);
            light.AddAttributeValue(Som.TrafficLightOC.position, light.TrafficLight.position);
            return (UpdateAttributeValues(light, "update/reflect"));
            /* }
             return false;*/
        }

        public bool turnWestToGreen(CTrafficLightHlaObject light)
        {
            if (light.TrafficLight.status != "Green")
            {
                light.TrafficLight.status = "Green";
                light.TrafficLight.timer = 30;
                light.AddAttributeValue(Som.TrafficLightOC.status, light.TrafficLight.status);
                light.AddAttributeValue(Som.TrafficLightOC.timer, light.TrafficLight.timer);
                light.AddAttributeValue(Som.TrafficLightOC.position, light.TrafficLight.position);
                return (UpdateAttributeValues(light, "update/reflect"));
            }
            return false;
        }
        public bool turnEastToYellow(CTrafficLightHlaObject light)
        {
            if (light.TrafficLight.status != "Yellow")
            {
                light.TrafficLight.status = "Yellow";
                light.TrafficLight.timer = 5;
                light.AddAttributeValue(Som.TrafficLightOC.status, light.TrafficLight.status);
                light.AddAttributeValue(Som.TrafficLightOC.timer, light.TrafficLight.timer);
                light.AddAttributeValue(Som.TrafficLightOC.position, light.TrafficLight.position);
                return (UpdateAttributeValues(light, "update/reflect"));
            }
            return false;
        }

        public bool changeEastToRed()
        {
            CTrafficLightHlaObject light = Program.TrafficLights[0];
            if (light.TrafficLight.status != "Red")
            {
                // Add Values
                light.TrafficLight.status = "Red";
                light.TrafficLight.timer = 0;
                light.AddAttributeValue(Som.TrafficLightOC.status, light.TrafficLight.status);
                light.AddAttributeValue(Som.TrafficLightOC.timer, light.TrafficLight.timer);
                light.AddAttributeValue(Som.TrafficLightOC.position, light.TrafficLight.position);
                return (UpdateAttributeValues(light, "update/reflect"));
            }
            return false;
        }
        public bool changeNorthToRed()
        {
            CTrafficLightHlaObject light = Program.TrafficLights[0];
            if (light.TrafficLight.status != "Red")
            {
                // Add Values
                light.TrafficLight.status = "Red";
                light.TrafficLight.timer = 0;
                light.AddAttributeValue(Som.TrafficLightOC.status, light.TrafficLight.status);
                light.AddAttributeValue(Som.TrafficLightOC.timer, light.TrafficLight.timer);
                light.AddAttributeValue(Som.TrafficLightOC.position, light.TrafficLight.position);
                return (UpdateAttributeValues(light, "update/reflect"));
            }
            return false;
        }
        public bool changeWestToRed()
        {
            CTrafficLightHlaObject light = Program.TrafficLights[0];
            if (light.TrafficLight.status != "Red")
            {
                // Add Values
                light.TrafficLight.status = "Red";
                light.TrafficLight.timer = 0;
                light.AddAttributeValue(Som.TrafficLightOC.status, light.TrafficLight.status);
                light.AddAttributeValue(Som.TrafficLightOC.timer, light.TrafficLight.timer);
                light.AddAttributeValue(Som.TrafficLightOC.position, light.TrafficLight.position);
                return (UpdateAttributeValues(light, "update/reflect"));
            }
            return false;
        }
        public bool turnNorthToYellow(CTrafficLightHlaObject light)
        {
            if (light.TrafficLight.status != "Yellow")
            {
                // Add Values
                light.TrafficLight.status = "Yellow";
                light.TrafficLight.timer = 5;
                light.AddAttributeValue(Som.TrafficLightOC.status, light.TrafficLight.status);
                light.AddAttributeValue(Som.TrafficLightOC.timer, light.TrafficLight.timer);
                light.AddAttributeValue(Som.TrafficLightOC.position, light.TrafficLight.position);
                return (UpdateAttributeValues(light, "update/reflect"));
            }
            return false;
        }
        public bool turnSouthToYellow(CTrafficLightHlaObject light)
        {
            if (light.TrafficLight.status != "Yellow")
            {
                // Add Values
                light.TrafficLight.status = "Yellow";
                light.TrafficLight.timer = 5;
                light.AddAttributeValue(Som.TrafficLightOC.status, light.TrafficLight.status);
                light.AddAttributeValue(Som.TrafficLightOC.timer, light.TrafficLight.timer);
                light.AddAttributeValue(Som.TrafficLightOC.position, light.TrafficLight.position);
                return (UpdateAttributeValues(light, "update/reflect"));
            }
            return false;
        }
        public bool turnSouthToGreen(CTrafficLightHlaObject light)
        {
            if (light.TrafficLight.status != "Green")
            {
                // Add Values
                light.TrafficLight.status = "Green";
                light.TrafficLight.timer = 30;
                light.AddAttributeValue(Som.TrafficLightOC.status, light.TrafficLight.status);
                light.AddAttributeValue(Som.TrafficLightOC.timer, light.TrafficLight.timer);
                light.AddAttributeValue(Som.TrafficLightOC.position, light.TrafficLight.position);
                return (UpdateAttributeValues(light, "update/reflect"));
            }
            return false;
        }
        public bool turnSouthToRed(CTrafficLightHlaObject light)
        {
            if (light.TrafficLight.status != "Red")
            {
                // Add Values
                light.TrafficLight.status = "Red";
                light.TrafficLight.timer = 0;
                light.AddAttributeValue(Som.TrafficLightOC.status, light.TrafficLight.status);
                light.AddAttributeValue(Som.TrafficLightOC.timer, light.TrafficLight.timer);
                light.AddAttributeValue(Som.TrafficLightOC.position, light.TrafficLight.position);
                return (UpdateAttributeValues(light, "update/reflect"));
            }
            return false;
        }
        public bool turnNorthToGreen(CTrafficLightHlaObject light)
        {
            if (light.TrafficLight.status != "Green")
            {
                // Add Values
                light.TrafficLight.status = "Green";
                light.TrafficLight.timer = 30;
                light.AddAttributeValue(Som.TrafficLightOC.status, light.TrafficLight.status);
                light.AddAttributeValue(Som.TrafficLightOC.timer, light.TrafficLight.timer);
                light.AddAttributeValue(Som.TrafficLightOC.position, light.TrafficLight.position);
                return (UpdateAttributeValues(light, "update/reflect"));
            }
            return false;
        }

        public void ChangeLight()
        {
           // Console.WriteLine("in change light!");
            if (Program.name.ToLower() == "east" && Program.west == 0 && Program.east == 0 && Program.TrafficLights[0].TrafficLight.status == "Yellow")
            {
                turnEastToGreen(Program.TrafficLights[0]);
            }

            else if (Program.name.ToLower() == "east" && Program.west == 0 && Program.east == 0 && Program.TrafficLights[0].TrafficLight.status == "Red")
            {
               // Console.WriteLine("in change light1231!");
                turnEastToYellow(Program.TrafficLights[0]);
            }
            
            else if (Program.name.ToLower() == "west" && Program.west == 0 && Program.east == 3 && Program.TrafficLights[0].TrafficLight.status == "Red")
            {
                turnWestToYellow(Program.TrafficLights[0]);
            }
            else if (Program.name.ToLower() == "west" && Program.west == 0 && Program.east == 4 && Program.TrafficLights[0].TrafficLight.status == "Yellow")
            {
                turnWestToGreen(Program.TrafficLights[0]);
            }
            else if (Program.name.ToLower() == "west" && Program.west == 0 && Program.east == 4 && Program.TrafficLights[0].TrafficLight.status == "Green")
            {
                turnWestToYellow(Program.TrafficLights[0]);
            }
            else if (Program.name.ToLower() == "north" && Program.north == 3 && Program.TrafficLights[0].TrafficLight.status == "Red")
            {
                turnNorthToYellow(Program.TrafficLights[0]);
            }
            else if (Program.name.ToLower() == "north" && Program.north == 4 && Program.TrafficLights[0].TrafficLight.status == "Yellow")
            {
                turnNorthToGreen(Program.TrafficLights[0]);
            }
            else if (Program.name.ToLower() == "north" && Program.north == 4 && Program.TrafficLights[0].TrafficLight.status == "Green")
            {
                turnNorthToYellow(Program.TrafficLights[0]);
            }
            else if (Program.name.ToLower() == "south" && Program.south == 0 && Program.TrafficLights[0].TrafficLight.status == "Red")
            {
                turnSouthToYellow(Program.TrafficLights[0]);
            }
            else if (Program.name.ToLower() == "south" && Program.south == 0 && Program.TrafficLights[0].TrafficLight.status == "Yellow")
            {
                turnSouthToGreen(Program.TrafficLights[0]);
            }
            else if (Program.name.ToLower() == "south" && Program.south == 0 && Program.TrafficLights[0].TrafficLight.status == "Green")
            {
                turnSouthToRed(Program.TrafficLights[0]);
            }
        }



        // Create AOR-1 (West)
        public void CreateWestRegion()
        {
            GetAllDimensionHandles();
            aor1 = new HlaRegion("aor1");
            List<HlaDimension> dimensions = new List<HlaDimension>();
            dimensions.Add(Som.AreaOfResponsibility);
            CreateRegion(aor1, dimensions);
            SetRangeBounds(aor1.Handle, Som.AreaOfResponsibility.Handle, 0, 1);
            List<HlaRegion> regions = new List<HlaRegion>();
            regions.Add(aor1);
            CommitRegionModifications(regions);
        }
        // Create AOR-2 (East)
        public void CreateEastRegion()
        {
            GetAllDimensionHandles();
            aor2 = new HlaRegion("aor2");
            List<HlaDimension> dimensions = new List<HlaDimension>();
            dimensions.Add(Som.AreaOfResponsibility);
            CreateRegion(aor2, dimensions);
            SetRangeBounds(aor2.Handle, Som.AreaOfResponsibility.Handle, 1, 2);
            List<HlaRegion> regions = new List<HlaRegion>();
            regions.Add(aor2);
            CommitRegionModifications(regions);
        }
        // Create AOR-3 (North)
        public void CreateNorthRegion()
        {
            GetAllDimensionHandles();
            aor2 = new HlaRegion("aor3");
            List<HlaDimension> dimensions = new List<HlaDimension>();
            dimensions.Add(Som.AreaOfResponsibility);
            CreateRegion(aor2, dimensions);
            SetRangeBounds(aor2.Handle, Som.AreaOfResponsibility.Handle, 2, 3);
            List<HlaRegion> regions = new List<HlaRegion>();
            regions.Add(aor2);
            CommitRegionModifications(regions);
        }
        // Create AOR-4 (South)
        public void CreateSouthRegion()
        {
            GetAllDimensionHandles();
            aor2 = new HlaRegion("aor4");
            List<HlaDimension> dimensions = new List<HlaDimension>();
            dimensions.Add(Som.AreaOfResponsibility);
            CreateRegion(aor2, dimensions);
            SetRangeBounds(aor2.Handle, Som.AreaOfResponsibility.Handle, 3, 4);
            List<HlaRegion> regions = new List<HlaRegion>();
            regions.Add(aor2);
            CommitRegionModifications(regions);
        }

        public void printMsgs()
        {
            Console.WriteLine("\n***************Printing Traffic Light Federates*******************\n");
            foreach (var item in Program.TrafficLights)
            {
                Console.WriteLine(item.TrafficLight.position + " is " + item.TrafficLight.status + " with timer " + item.TrafficLight.timer);
                //Console.WriteLine(item.Name + " has sign of " + item.TrafficLight.status);
                //Console.WriteLine(item.Name + " has Duration of " + item.TrafficLight.timer);
               // Console.WriteLine(item.Name + " has Position of " + item.TrafficLight.position);
            }
            Console.WriteLine("\n**********************************************************************\n");
        }
        #endregion //Manually Added Code
    }
}
