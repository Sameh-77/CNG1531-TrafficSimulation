﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TrafficSimulation.Som;

namespace TrafficSimulation
{
    public class CTrafficLight
    {

        public string status;
        public int timer;
        public string position;

        public CTrafficLight()
        {
            status = "Red";
            timer = 1;
            position = "tmp";

        }

        public void setPosition(string name)
        {
            if(name.ToLower() == "east")
            {
                position = "east";
            }
            else if (name.ToLower() == "west")
            {
                position = "west";
            }
            else if (name.ToLower() == "north")
            {
                position = "north";
            }
            else
            {
                position = "south";
            }
        }
    }
}
