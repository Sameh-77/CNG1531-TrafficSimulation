﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
//Racon
using Racon;
using Racon.RtiLayer;
// Application
using TrafficSimulation.Som;

namespace TrafficSimulation
{
    public class Program
    {
        static public CVehicleApp vehicleFd;
        static public CVehicleHlaObject VehicleObject;
        static public CTrafficLightHlaObject TrafficLights;
        static public HlaRegion myAor;
        static public bool updated = false;

        static void Main(string[] args)
        {

            Console.WriteLine("Main Vehcile Federate Program");

            // Instantiation
            vehicleFd = new CVehicleApp();


            

            Console.WriteLine("Enter The vehicle configurations:\n*********************************************************\n");

            VehicleObject = new CVehicleHlaObject(vehicleFd.Som.VehicleOC);

            vehicleFd.FederationExecution.FederateName = "VehicleFedrate" + VehicleObject.Vehicle.id;
            vehicleFd.FederationExecution.Name = "TrafficFederation";
            vehicleFd.FederationExecution.FederateType = "Vehicle";
            vehicleFd.FederationExecution.ConnectionSettings = "rti://127.0.0.1";
            vehicleFd.FederationExecution.FDD = @"C:\Users\TOSHIBA\Desktop\Masters\1st Semester\CNG1531\new\TrafficSimulation\VehicleFdApp\FDD\TrafficSimulationFOM.xml";
            
            vehicleFd.StatusMessageChanged += Federate_StatusMessageChanged;
            vehicleFd.LogLevel = LogLevel.ALL;
            
            PrintVersion();
            printConfiguration();// report to user
            
            // Connect
            vehicleFd.Connect(CallbackModel.EVOKED, vehicleFd.FederationExecution.ConnectionSettings);
            // Create federation execution
            vehicleFd.CreateFederationExecution(vehicleFd.FederationExecution.Name, vehicleFd.FederationExecution.FomModules);
            // Join federation execution
            vehicleFd.JoinFederationExecution(vehicleFd.FederationExecution.FederateName, vehicleFd.FederationExecution.FederateType, vehicleFd.FederationExecution.Name, vehicleFd.FederationExecution.FomModules);

            // Declare Capability
            vehicleFd.DeclareCapability();


            TrafficLights = new CTrafficLightHlaObject(vehicleFd.Som.TrafficLightOC);

            do
            {
                vehicleFd.Run();
                if (!updated)
                {
                    vehicleFd.UpdateVehicleAttribute(VehicleObject);
                    updated = true;
                }
                
            } while (Console.ReadKey(true).Key != ConsoleKey.Escape && VehicleObject.Vehicle.vehicleStatus != "move");

            // *************************************************
            // Shutdown
            // *************************************************

           

            vehicleFd.DeleteObjectInstance(VehicleObject);
            vehicleFd.FinalizeFederation(vehicleFd.FederationExecution, ResignAction.NO_ACTION);

            // Dumb trace log
            System.IO.StreamWriter file = new System.IO.StreamWriter(@".\TraceLog.txt");
            file.WriteLine(vehicleFd.TraceLog);
            file.Close();
            

            // Keep the console window open in debug mode.
            Console.WriteLine("Press any key to exit.");
            Console.ReadKey();
        }

        private static void printConfiguration()
        {
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine(
              "***************************************************************************\n");
            Console.WriteLine("\nThanks for input! The local vehicle configuration: \n");
            Console.WriteLine("ID: {0}", VehicleObject.Vehicle.id);
            Console.WriteLine("Position: {0}", VehicleObject.Vehicle.position);
            Console.WriteLine("Vehicle Emergency status: {0}", VehicleObject.Vehicle.emergencyStatus);
            Console.WriteLine("Vehicle Counter: {0}", VehicleObject.Vehicle.counter);
            Console.WriteLine("Vehicle Status: {0}", VehicleObject.Vehicle.vehicleStatus);
            Console.WriteLine(
              "***************************************************************************\n");


        }
        // Racon Information received
        private static void Federate_StatusMessageChanged(object sender, EventArgs e)
        {
            Console.ResetColor();
            Console.WriteLine((sender as CVehicleApp).StatusMessage);
        }

        private static void PrintVersion()
        {
            Console.WriteLine(
              "***************************************************************************\n"
              + "                        " + "VehicleFdApp v1.0.0" + "\n"
              + "***************************************************************************");
        }
    }
}
