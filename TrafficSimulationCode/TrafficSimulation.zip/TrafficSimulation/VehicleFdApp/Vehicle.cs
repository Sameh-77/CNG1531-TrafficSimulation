using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
// Racon
using Racon;
using Racon.RtiLayer;
// App
using TrafficSimulation.Som;

namespace TrafficSimulation
{
    public class CVehicle
    {
        public string id;
        public int counter;
        public bool emergencyStatus;
        public string vehicleStatus;
        public string position;
        //public StatusEnum Status;

        public CVehicle()
        {
            id = GetVehicleId();
            position = GetDirection();
            counter = 0;
            emergencyStatus = GetVehicleEmergencyStatus();
            vehicleStatus = "stop";
    }

        public string GetVehicleId()
        {
            Console.WriteLine("Enter Vehicle id 'plate number': ");
            string Vid = Console.ReadLine();
            this.counter++;
            return Vid;
        }

        public string GetDirection()
        {
            Console.WriteLine("Direction it is coming from East, West, North, South : ");
            string d = Console.ReadLine();
            if (d.ToLower() == "east") return "east";
            else if (d.ToLower() == "west") return "west";
            else if (d.ToLower() == "north") return "north";
            else if (d.ToLower() == "south") return "south";
            else Console.WriteLine("Wrong Input, Default Direction is EAST"); return "south";
        }

        public bool GetVehicleEmergencyStatus()
        {
            Console.WriteLine("Is it an emergnecy vehicle? Enter 'yes' or 'no': ");
            string answer = Console.ReadLine();
            while (answer.ToLower() != "yes" && answer.ToLower() != "no")
            {
                Console.WriteLine("Wrong Input! Try again!");
                Console.WriteLine("Is it an emergnecy vehicle? Enter 'yes' or 'no': ");
                answer = Console.ReadLine();
            }
            bool emergency=false;
            if (answer.ToLower() == "yes")
                emergency = true;
            else if (answer.ToLower() == "no")
                emergency = false;

            return emergency;
        }
    }
}
